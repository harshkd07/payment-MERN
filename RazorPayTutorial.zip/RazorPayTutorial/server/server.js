import express from "express";
import { config } from "dotenv";
import Razorpay from "razorpay";
import paymentRoute from "./routes/paymentRoutes.js";
import cors from "cors";
import { connectDB } from "./config/database.js";

// Load environment variables from config.env
config({ path: "./config/config.env" });

export const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Initialize Razorpay instance
export const instance = new Razorpay({
  key_id: process.env.RAZORPAY_API_KEY,
  key_secret: process.env.RAZORPAY_APT_SECRET,
});

app.use("/api", paymentRoute);

app.get("/api/getkey", (req, res) =>
  res.status(200).json({ key: process.env.RAZORPAY_API_KEY })
);

// Connect to the database
connectDB().catch((error) => {
  console.error("Database connection error:", error);
  process.exit(1); // Exit process with failure
});

// Start the server
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Server is working on ${PORT}`);
});
